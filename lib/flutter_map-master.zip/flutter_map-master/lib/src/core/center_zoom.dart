import 'package:latlong/latlong.dart';

class CenterZoom {
  final LatLng center;
  final double zoom;
  CenterZoom({this.center, this.zoom});
}
