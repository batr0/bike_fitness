class LayerOptions {
  Stream<Null> rebuild;
  LayerOptions({this.rebuild});
}
